import ProductsFetch from "@/src/units/products/08-fetch/productsFetch.container"

export default function ProductFetchMain() {
  
  
  return <ProductsFetch />
}