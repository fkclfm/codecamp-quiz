import ProductCreate from "../../../src/units/products/07-write/productsCreate.container"

export default function ProductsCreateMain() {
  
  return <ProductCreate />
}
